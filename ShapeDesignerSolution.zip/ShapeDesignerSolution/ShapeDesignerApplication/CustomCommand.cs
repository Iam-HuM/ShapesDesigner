﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ShapeDesignerApplication
{
    /// <summary>
    /// This class is used to define a custom action command.
    /// </summary>
    public class CustomCommand : ICommand
    {

        #region Propeties
        /// <summary>
        /// Gets or sets the Predicate to execute when the CanExecute of the command gets called
        /// </summary>
        public Predicate<object> CanExecuteDelegate { get; set; }

        /// <summary>
        /// Gets or sets the action to be called when the Execute method of the command gets called
        /// </summary>
        public Action<object> ExecuteDelegate { get; set; }

        #endregion


        #region Constructors


        /// <summary>
        /// Initializes a new instance of the <see cref="CustomCommand" /> class.
        /// Default Constructor.
        /// </summary>
        /// <param name="canExecuteDelegate">Can execute delegate.</param>
        /// <param name="executeDelegate">Execute delecte action.</param>
        public CustomCommand(Predicate<object> canExecuteDelegate, Action<object> executeDelegate)
        {
            CanExecuteDelegate = canExecuteDelegate;
            ExecuteDelegate = executeDelegate;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomCommand" /> class.
        /// Default Constructor.
        /// </summary>
        /// <param name="executeDelegate">Execute delecte action.</param>
        public CustomCommand(Action<object> executeDelegate)
        {
            ExecuteDelegate = executeDelegate;
        }
        #endregion


        #region ICommand Members

        /// <summary>
        /// Checks if the command Execute method can run
        /// </summary>
        /// <param name="parameter">THe command parameter to be passed</param>
        /// <returns>Returns true if the command can execute. By default true is returned so that if the user of SimpleCommand does not specify a CanExecuteCommand delegate the command still executes.</returns>
        public bool CanExecute(object parameter)
        {
            if (CanExecuteDelegate != null)
                return CanExecuteDelegate(parameter);

            return true;// if there is no can execute default to true
        }

        /// <summary>
        /// Gets or sets the execuation changed state.
        /// </summary>
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        /// <summary>
        /// Executes the actual command
        /// </summary>
        /// <param name="parameter">THe command parameter to be passed</param>
        public void Execute(object parameter)
        {
            if (ExecuteDelegate != null)
            {
                ExecuteDelegate(parameter);
            }
        }

        #endregion
    }
}
