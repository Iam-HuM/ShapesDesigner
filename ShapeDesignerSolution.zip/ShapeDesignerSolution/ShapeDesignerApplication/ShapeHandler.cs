﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDesignerApplication
{

    /// <summary>
    /// This class is binded to canvas and canvas child elements are binded to 'CanvasChildrens'
    /// </summary>
    public class ShapeHandler
    {
        private static double LeftIncrementor = 0;
        private static double TopIncrementor = 0; 
        private static double AngleIncrementor = 0;


        private ObservableCollection<ShapeDiagram> canvasChildrens;
        public ObservableCollection<ShapeDiagram> CanvasChildrens
        {
            get
            {
                return canvasChildrens;
            }
            set
            {
                canvasChildrens = value;
                Notify("CanvasChildrens");
            }
        }

        private static ShapeHandler instance;

        public static ShapeHandler Instance
        {
            get
            {
                if (null == instance)
                {
                    instance = new ShapeHandler();
                }

                return instance;
            }
            //set { instance = value; }
        }


        private ShapeDiagram currentSelectedShape;

        public ShapeDiagram CurrentSelectedShape
        {
            get { return currentSelectedShape; }
            set {
                UnSelectAllShapes();
                if (value != null)
                {
                    currentSelectedShape = value;
                    currentSelectedShape.IsSelected = true;
                }
                Notify("CurrentSelectedShape");
            }
        }


        private ShapeHandler()
        {
            this.CanvasChildrens = new ObservableCollection<ShapeDiagram>();

            AddRectangleCommand = new CustomCommand(ExecuteAddRectangleCommand);
            AddGroupCommand = new CustomCommand(ExecuteAddGroupCommand);
            DeleteSelectedCommand = new CustomCommand(ExecuteDeleteSelectedCommand);
            ClearCommand = new CustomCommand(ExecuteClearCommand);
            GroupCommand = new CustomCommand(ExecuteGroupCommand);
            UngroupCommand = new CustomCommand(ExecuteUngroupCommand);

            // Add dummy shapes
            this.CanvasChildrens.Add(new ShapeDiagram(0, 0, 0));
            this.CanvasChildrens.Add(new ShapeDiagram(50, 50, 10));
            this.CanvasChildrens.Add(new ShapeDiagram(100, 100, 20));
            this.CanvasChildrens.Add(new ShapeDiagram(150, 150, 30));
            //this.CanvasChildrens.Add(new ShapeDiagram(200, 200, 45));
            //this.CanvasChildrens.Add(new ShapeDiagram(250, 250, 60));
            //this.CanvasChildrens.Add(new ShapeDiagram(300, 300, 75));

            CreateGroupShape();

            // Select Groped shape for ungrouping directly
            this.CurrentSelectedShape = this.CanvasChildrens[4];
        }

        private void CreateGroupShape()
        {
            GroupShapeDiagram group = new GroupShapeDiagram();
            ShapeDiagram shape1 = new ShapeDiagram(20, 20, 0);
            ShapeDiagram shape2 = new ShapeDiagram(60, 60, 30);
            ShapeDiagram shape3 = new ShapeDiagram(110, 110, 45);
            ShapeDiagram shape4 = new ShapeDiagram(160, 160, 60);

            group.Left = 300;
            group.Top = 300;
            group.Width = 200;
            group.Height = 200;
            group.Angle = 30;
            group.IsSelected = true;

            group.Childrens.Add(shape1);
            group.Childrens.Add(shape2);
            group.Childrens.Add(shape3);
            group.Childrens.Add(shape4);

            group.UpdateCaption(group.GetCaption());

            this.CanvasChildrens.Add(group);
        }

        public CustomCommand AddRectangleCommand { get; private set; }
        public CustomCommand AddGroupCommand { get; private set; }
        public CustomCommand DeleteSelectedCommand { get; private set; }
        public CustomCommand ClearCommand { get; private set; }
        public CustomCommand GroupCommand { get; private set; }
        public CustomCommand UngroupCommand { get; private set; }


        public void ExecuteAddRectangleCommand(object parameter)
        {
            this.CanvasChildrens.Add(new ShapeDiagram(LeftIncrementor, TopIncrementor, AngleIncrementor));

            LeftIncrementor += 10;
            TopIncrementor += 10;
            AngleIncrementor += 10;
        }

        public void ExecuteAddGroupCommand(object parameter)
        {
            CreateGroupShape();
        }

        public void ExecuteDeleteSelectedCommand(object parameter)
        {
            List<ShapeDiagram> toBeDeleted = new List<ShapeDiagram>();

            foreach(ShapeDiagram shape in this.CanvasChildrens)
            {
                if(shape.IsSelected)
                {
                    toBeDeleted.Add(shape);
                }
            }

            foreach (ShapeDiagram shape in toBeDeleted)
            {
                this.CanvasChildrens.Remove(shape);
            }
        }

        public void ExecuteClearCommand(object parameter)
        {
            this.CanvasChildrens.Clear();
        }
        public void ExecuteGroupCommand(object parameter)
        {
            ObservableCollection<ShapeDiagram> toBeGrouped = new ObservableCollection<ShapeDiagram>();

            foreach (ShapeDiagram shape in this.CanvasChildrens)
            {
                if (shape.IsSelected)
                {
                    toBeGrouped.Add(shape);
                }
            }

            UnSelectAllShapes();

            DoGrouping(toBeGrouped);
        }
        public void ExecuteUngroupCommand(object parameter)
        {
            if(parameter == null)
            {
                parameter = this.CurrentSelectedShape;
            }

            DoUnGrouping(parameter as GroupShapeDiagram);
        }

        public void AddCanvasChild(ShapeDiagram shape)
        {
            if (shape != null)
            {
                this.CanvasChildrens.Add(shape);
            }
        }
    
        public void RemoveCanvasChild(ShapeDiagram shape)
        {
            if (shape != null)
            {
                this.CanvasChildrens.Remove(shape);
            }
        }


        public GroupShapeDiagram DoGrouping(ObservableCollection<ShapeDiagram> childrens)
        {
            GroupShapeDiagram newGroup = new GroupShapeDiagram();

            newGroup.Childrens = childrens;
            newGroup.Angle = AngleIncrementor;
            newGroup.Top = TopIncrementor;
            newGroup.Left = LeftIncrementor;
            newGroup.Width = GetNewGroupWidth(childrens);
            newGroup.Height = GetNewGroupHeight(childrens);

            // Add new group in the canvas child shapes collection
            this.CanvasChildrens.Add(newGroup);
            newGroup.IsSelected = true;
            this.CurrentSelectedShape = newGroup;


            LeftIncrementor += 10;
            TopIncrementor += 10;
            AngleIncrementor += 10;

            return newGroup;
        }

        public void DoUnGrouping(GroupShapeDiagram group)
        {
            if(group == null)
            {
                return;
            }

            // Remove selected group from the canvas child shapes collection
            this.CanvasChildrens.Remove(group);

            // TO-DO: Now adjust the group child shapes to correct location
            // *** This is where i am not getting correct values for Top/Left/Angle for child shapes after ungrouping
            foreach (ShapeDiagram childShape in group.Childrens)
            {
                childShape.Angle += group.Angle;

                childShape.IsSelected = true;

                //// If you rotate point (px, py) around point (ox, oy) by angle theta you'll get:
                // p'x = cos(theta) * (px-ox) - sin(theta) * (py-oy) + ox
                // p'y = sin(theta) * (px-ox) + cos(theta) * (py-oy) + oy
                double theta = group.Angle * -1;
                double px = childShape.Left + group.Left;
                double py = childShape.Top + group.Top;

                double ox = group.Left + (group.Width / 2);
                double oy = group.Top + (group.Height / 2);

                double newx = (Math.Cos(theta) * (px - ox) - Math.Sin(theta) * (py - oy) + ox);
                double newy = (Math.Sin(theta) * (px - ox) + Math.Cos(theta) * (py - oy) + oy);

                childShape.Left = newx ;
                childShape.Top = newy;

                this.CanvasChildrens.Add(childShape);
            }
        }

        private double GetNewGroupWidth(ObservableCollection<ShapeDiagram> childrens)
        {
            double maxWidth = 300;

            // TO-DO: Logic to get max width of all childrens with some buffer width, for now I am returning 300 as default group width

            return maxWidth;
        }

        private double GetNewGroupHeight(ObservableCollection<ShapeDiagram> childrens)
        {
            double maxHeight = 300;

            // TO-DO: Logic to get max heigth of all childrens with some buffer heigth, for now I am returning 300 as default group height

            return maxHeight;
        }

        public void UnSelectAllShapes()
        {
            foreach (ShapeDiagram shape in this.CanvasChildrens)
            {
                shape.IsSelected = false;
            }
        }


        #region Events

        /// <summary>
        /// This event is used to handle any change in the property.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion


        #region Methods

        /// <summary>
        /// This method will be used to handle notifications for any property change.
        /// </summary>
        /// <param name="properties">Property names which are modified/updated/changed.</param>
        protected virtual void Notify(params string[] properties)
        {
            if (properties != default(string[]))
            {
                foreach (var propertyName in properties)
                {
                    if (!string.IsNullOrEmpty(propertyName) &&
                        PropertyChanged != default(PropertyChangedEventHandler))
                    {
                        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
                    }
                }
            }
        }

        #endregion
    }
}
