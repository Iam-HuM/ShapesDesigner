﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDesignerApplication
{
    /// <summary>
    /// Group can have more than one 'ShapeDiagram' elements. A custom shape can be created using child 'ShapeDiagram' elements.
    /// User can rotate multiple 'ShapeDiagram' elements and create a group.
    /// Group will have a rectangle border around the childrens as shown in the above image.
    /// Group rectangle border is created using templates based on type like GroupShapeDigram or ShapeDiagram.
    /// </summary>
    public class GroupShapeDiagram : ShapeDiagram
    {
        public ObservableCollection<ShapeDiagram> childrens;

        public ObservableCollection<ShapeDiagram> Childrens
        {
            get
            {
                return childrens;
            }
            set
            {
                childrens = value;
                Notify("Childrens");
            }
        }

        public GroupShapeDiagram()
        {
            this.Childrens = new ObservableCollection<ShapeDiagram>();


            base.UpdateCaption(GetCaption());
        }

    }
}
