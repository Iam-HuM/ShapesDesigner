﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ShapeDesignerApplication
{
    public class ShapeSelector : StyleSelector
    {

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="DesignerItemsControlItemStyleSelector" /> class.
        /// Overloaded Constructor.
        /// </summary>
        static ShapeSelector()
        {
            Instance = new ShapeSelector();
        }

        #endregion


        #region Proeprties

        /// <summary>
        /// Gets the singleton object of the style selector.
        /// </summary>
        public static ShapeSelector Instance
        {
            get;
            private set;
        }


        #endregion


        #region Methods

        /// <summary>
        /// This method will select the style for the item.
        /// </summary>
        /// <param name="item"></param>
        /// <param name="container"></param>
        /// <returns></returns>
        public override Style SelectStyle(object item, DependencyObject container)
        {
            ItemsControl itemsControl = ItemsControl.ItemsControlFromItemContainer(container);
            if (itemsControl == null)
                throw new InvalidOperationException("ShapeSelector : Could not find ItemsControl");

            if (item is ShapeDiagram)
            {
                return (Style)itemsControl.FindResource("shapeBasedDesignerElementStyle");
            }

            if (item is GroupShapeDiagram)
            {
                return (Style)itemsControl.FindResource("groupShapeBasedDesignerElementStyle");
            }



            return null;
        }


        #endregion


    }
}
