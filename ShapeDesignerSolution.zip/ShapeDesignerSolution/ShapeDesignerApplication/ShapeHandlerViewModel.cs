﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDesignerApplication
{
    public class ShapeHandlerViewModel
    {
        private ShapeHandler shapeHandlerInstance;

        public ShapeHandler ShapeHandlerInstance
        {
            get { return shapeHandlerInstance; }
            set { shapeHandlerInstance = value;
                Notify("ShapeHandlerInstance");
            }
        }

        public ShapeHandlerViewModel()
        {
            this.ShapeHandlerInstance = ShapeHandler.Instance;
        }

        #region Events

        /// <summary>
        /// This event is used to handle any change in the property.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion


        #region Methods

        /// <summary>
        /// This method will be used to handle notifications for any property change.
        /// </summary>
        /// <param name="properties">Property names which are modified/updated/changed.</param>
        protected virtual void Notify(params string[] properties)
        {
            if (properties != default(string[]))
            {
                foreach (var propertyName in properties)
                {
                    if (!string.IsNullOrEmpty(propertyName) &&
                        PropertyChanged != default(PropertyChangedEventHandler))
                    {
                        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
                    }
                }
            }
        }

        #endregion

    }
}
