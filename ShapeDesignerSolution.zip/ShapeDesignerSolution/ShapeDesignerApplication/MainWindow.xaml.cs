﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ShapeDesignerApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ShapeHandlerViewModel shapeHandler;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            shapeHandler = new ShapeHandlerViewModel();
            this.DataContext = shapeHandler.ShapeHandlerInstance;
        }

        private void Canvas_Loaded(object sender, RoutedEventArgs e)
        {
            gridMain.DataContext = ShapeHandler.Instance;
            object dataContext = (sender as Canvas).DataContext;

        }

        private void designerCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if(e.Source as Rectangle != null)
            {
                if (((e.Source as Rectangle).DataContext is GroupShapeDiagram))
                {
                    GroupShapeDiagram shapeDiagram = ((e.Source as Rectangle).DataContext as GroupShapeDiagram);

                    shapeDiagram.IsSelected = !shapeDiagram.IsSelected;
                }
                else if (((e.Source as Rectangle).DataContext is ShapeDiagram))
                {
                    ShapeDiagram shapeDiagram = ((e.Source as Rectangle).DataContext as ShapeDiagram);

                    shapeDiagram.IsSelected = !shapeDiagram.IsSelected;
                }
            }
        }

        private void ComboBox_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void comboBoxShapesRepository_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //shapeHandler.ShapeHandlerInstance.CurrentSelectedShape = ((sender as ComboBox).SelectedItem as ShapeDiagram);
        }

        private void designerCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            //(sender as Canvas).OnMouseMove(e);

            if ((sender as Canvas).ToolTip != null)
            {
                if ((sender as Canvas).ToolTip is ToolTip)
                {
                    ((sender as Canvas).ToolTip as ToolTip).StaysOpen = true;
                }
            }

            (sender as Canvas).ToolTip = e.GetPosition(this);
        }
    }
}
