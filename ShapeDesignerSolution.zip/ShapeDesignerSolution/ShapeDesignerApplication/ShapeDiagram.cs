﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDesignerApplication
{

    /// <summary>
    /// ShapeDiagram can be any shape like Rectangle/Triangle/Ellipse etc.
    /// For now I am using only Rectangle template for 'ShapeDiagram' type.
    /// </summary>
    public class ShapeDiagram
    {
        public static uint UniqueIdentifier = 0;

        private uint ID;


        private double left;
        private double top;
        private double angle;
        private double width;
        private double height;
        private bool isSelected;

        public double Left
        {
            get
            {
                return left;
            }
            set
            {
                left = value;
                Notify("Left");

                caption = GetCaption();
                Notify("Caption");
            }
        }

        public double Top
        {
            get
            {
                return top;
            }
            set
            {
                top = value;
                Notify("Top");

                caption = GetCaption();
                Notify("Caption");
            }
        }
        public double Angle
        {
            get
            {
                return angle;
            }
            set
            {
                angle = value;
                Notify("Angle");

                caption = GetCaption();
                Notify("Caption");
            }
        }

        internal void UpdateCaption(string caption)
        {
            this.caption = caption;
        }

        public double Width
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
                Notify("Width");

                caption = GetCaption();
                Notify("Caption");
            }
        }
        public double Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
                Notify("Height");

                caption = GetCaption();
                Notify("Caption");
            }
        }

        public bool IsSelected
        {
            get
            {
                return isSelected;
            }
            set
            {
                isSelected = value;
                Notify("IsSelected");
            }
        }


        public ShapeDiagram()
        {
            ID = UniqueIdentifier++;

            this.Width = 30;
            this.Height = 30;

            this.caption = GetCaption();
        }

        public ShapeDiagram(double left, double top, double angle ) : this()
        {
            this.Left = left;
            this.Top = top;
            this.Angle = angle;
            this.IsSelected = true;

            this.caption = GetCaption();
        }

        private string caption;

        public string Caption
        {
            get
            {
                return caption;
            }
        }

        public string GetCaption()
        {
            StringBuilder caption = new StringBuilder();

            if (this is GroupShapeDiagram)
            {
                caption.Append("Group - " + ID.ToString() + ": {");
                caption.Append("Left= " + Left.ToString() + ", ");
                caption.Append("Top= " + Top.ToString() + ", ");
                caption.Append("Width= " + Width.ToString() + ", ");
                caption.Append("Height= " + Height.ToString() + ", ");
                caption.Append("Angle= " + Angle.ToString() + "}");
            }
            else if(this is ShapeDiagram)
            {
                caption.Append("Rectangle - " + ID.ToString() + ": {");
                caption.Append("Left= " + Left.ToString() + ", ");
                caption.Append("Top= " + Top.ToString() + ", ");
                caption.Append("Width= " + Width.ToString() + ", ");
                caption.Append("Height= " + Height.ToString() + ", ");
                caption.Append("Angle= " + Angle.ToString() + "}");
            }

            return caption.ToString();
        }

        public override string ToString()
        {
            return caption.ToString();
        }

        #region Events

        /// <summary>
        /// This event is used to handle any change in the property.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion


        #region Methods

        /// <summary>
        /// This method will be used to handle notifications for any property change.
        /// </summary>
        /// <param name="properties">Property names which are modified/updated/changed.</param>
        protected virtual void Notify(params string[] properties)
        {
            if (properties != default(string[]))
            {
                foreach (var propertyName in properties)
                {
                    if (!string.IsNullOrEmpty(propertyName) &&
                        PropertyChanged != default(PropertyChangedEventHandler))
                    {
                        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
                    }
                }
            }
        }

        #endregion
    }
}
